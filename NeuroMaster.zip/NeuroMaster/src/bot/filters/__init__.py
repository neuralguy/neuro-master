"""Bot filters."""

from src.bot.filters.admin import AdminFilter

__all__ = ["AdminFilter"]
