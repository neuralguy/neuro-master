"""Telegram bot module."""

from src.bot.loader import bot, dp

__all__ = ["bot", "dp"]
